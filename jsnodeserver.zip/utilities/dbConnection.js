//Database connections is now managed using /models/index.js file iusing sequelize.
//Connection configurations are provide inside /configs in respective <environment>.json file